sap.ui.define([
	"com/globalintelli/ZAE_SCIN/test/unit/controller/App.controller"
], function () {
	"use strict";
});
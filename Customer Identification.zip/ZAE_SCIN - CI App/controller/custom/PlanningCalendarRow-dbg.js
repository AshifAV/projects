 /*!
  * OpenUI5
  * (c) Copyright 2009-2019 SAP SE or an SAP affiliate company.
  * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
  */
 sap.ui.define([
 	'sap/m/PlanningCalendarRow',
 	'sap/ui/core/Element',
 	'sap/m/CustomListItem'
 	// 'sap/m/sample/PlanningCalendarWithLegend/custom/CustomListItem',
 ], function (PlanningCalendarRow, E, C /*, C2*/ ) {
 	"use strict";
 	var P = PlanningCalendarRow.extend("com.globalintelli.ZAE_SCIN.controller.custom.PlanningCalendarRow", {
 		metadata: {
 			library: "sap.m",
 			properties: {
 				AvailableTime: {
 					type: "string",
 					group: "Data"
 				},
 				BookedTime: {
 					type: "string",
 					group: "Data"
 				},
 				RemainingTime: {
 					type: "string",
 					group: "Data"
 				},
 				title: {
 					type: "string",
 					group: "Data"
 				},
 				text: {
 					type: "string",
 					group: "Data"
 				},
 				icon: {
 					type: "sap.ui.core.URI",
 					group: "Data",
 					defaultValue: null
 				},
 				nonWorkingDays: {
 					type: "int[]",
 					group: "Misc",
 					defaultValue: null
 				},
 				nonWorkingHours: {
 					type: "int[]",
 					group: "Misc",
 					defaultValue: null
 				},
 				selected: {
 					type: "boolean",
 					group: "Data",
 					defaultValue: false
 				},
 				key: {
 					type: "string",
 					group: "Data",
 					defaultValue: null
 				},
 				enableAppointmentsDragAndDrop: {
 					type: "boolean",
 					group: "Misc",
 					defaultValue: false
 				},
 				enableAppointmentsResize: {
 					type: "boolean",
 					group: "Misc",
 					defaultValue: false
 				},
 				enableAppointmentsCreate: {
 					type: "boolean",
 					group: "Misc",
 					defaultValue: false
 				}
 			},
 			aggregations: {
 				appointments: {
 					type: "sap.ui.unified.CalendarAppointment",
 					multiple: true,
 					singularName: "appointment",
 					dnd: {
 						draggable: true
 					}
 				},
 				intervalHeaders: {
 					type: "sap.ui.unified.CalendarAppointment",
 					multiple: true,
 					singularName: "intervalHeader"
 				},
 				specialDates: {
 					type: "sap.ui.unified.DateTypeRange",
 					multiple: true,
 					singularName: "specialDate"
 				},
 				headerContent: {
 					type: "sap.ui.core.Control",
 					multiple: true,
 					singularName: "headerContent",
 					forwarding: {
 						getter: "_getPlanningCalendarCustomRowHeader",
 						aggregation: "content"
 					},
 					forwardBinding: true
 				}
 			},
 			events: {
 				appointmentDrop: {
 					parameters: {
 						appointment: {
 							type: "sap.ui.unified.CalendarAppointment"
 						},
 						startDate: {
 							type: "object"
 						},
 						endDate: {
 							type: "object"
 						},
 						calendarRow: {
 							type: "sap.m.PlanningCalendarRow"
 						},
 						copy: {
 							type: "boolean"
 						}
 					}
 				},
 				appointmentDragEnter: {
 					allowPreventDefault: true,
 					parameters: {
 						appointment: {
 							type: "sap.ui.unified.CalendarAppointment"
 						},
 						startDate: {
 							type: "object"
 						},
 						endDate: {
 							type: "object"
 						},
 						calendarRow: {
 							type: "sap.m.PlanningCalendarRow"
 						}
 					}
 				},
 				appointmentResize: {
 					parameters: {
 						appointment: {
 							type: "sap.ui.unified.CalendarAppointment"
 						},
 						startDate: {
 							type: "object"
 						},
 						endDate: {
 							type: "object"
 						}
 					}
 				},
 				appointmentCreate: {
 					parameters: {
 						startDate: {
 							type: "object"
 						},
 						endDate: {
 							type: "object"
 						},
 						calendarRow: {
 							type: "sap.m.PlanningCalendarRow"
 						}
 					}
 				}
 			}
 		}
 	});
 	P.prototype.exit = function () {
 		if (this.oRowHeader) {
 			this.oRowHeader.destroy();
 		}
 	};

 	P.prototype._getPlanningCalendarCustomRowHeader = function () {
 		if (!this.oRowHeader) {
 			this.oRowHeader = new C(this.getId() + "-CustomHead");
 		}
 		return this.oRowHeader;
 	};

 	P.prototype._getPlanningCalendarCustomRowHeader_cust = function () {
 		debugger
 		if (!this.oRowHeader) {
 			this.oRowHeader = new sap.m.CustomListItem("CustomHead", {
 				content: [
 					new sap.m.FlexBox({
 						items: [
 							new sap.suite.ui.microchart.ColumnMicroChart({
 								columns: [
 									new sap.suite.ui.microchart.ColumnMicroChartData({
 										value: 5
 									}),
 									new sap.suite.ui.microchart.ColumnMicroChartData({
 										value: 10
 									}),
 									new sap.suite.ui.microchart.ColumnMicroChartData({
 										value: 20
 									}),

 								]
 							})
 						]
 					})
 				]
 			});
 		}
 		return this.oRowHeader;
 	};

 	P.prototype._getPlanningCalendarCustomRowID = function () {
 		return this.getId();
 	};
 	P.prototype._getBookedTime = function () {

 	};

 	return P;
 });